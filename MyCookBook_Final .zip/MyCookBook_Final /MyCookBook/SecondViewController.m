//
//  SecondViewController.m
//  MyCookBook
//
//  Created by Neeraj Shukla on 31/10/14.
//  Copyright (c) 2014 stpl. All rights reserved.
//

#import "SecondViewController.h"
//#import "FirstViewController.h"
#import "DetailViewController.h"
#import "AppDelegate.h"

@interface SecondViewController ()

@end

@implementation SecondViewController
    
NSMutableArray *fav;
NSDictionary *dict ;

- (void)viewDidLoad

{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"newList" ofType:@"plist"];
    //Load the file content and read the data into arrays
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSString *filePath = delegate.plistPathInDocumentDirectory;

  dict = [[NSDictionary alloc] initWithContentsOfFile:filePath];
    
   fav = [dict objectForKey:@"Favourites"];

    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSString *filePath = delegate.plistPathInDocumentDirectory;

   // NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
   // NSString *documentsDirectory = [paths objectAtIndex:0];
    
  //  NSString *filePath = [documentsDirectory stringByAppendingString:@"newList.plist"];
    
    
//    
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"newList" ofType:@"plist"];
//    //Load the file content and read the data into arrays
//    //AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//    //NSString *filePath = delegate.plistPathInDocumentDirectory;
//    
//    dict = [[NSDictionary alloc] initWithContentsOfFile:filePath];
//    
//    fav = [dict objectForKey:@"Favourites"];

    
    NSFileManager *manager = [NSFileManager defaultManager];
    
    if (![manager fileExistsAtPath:filePath]) {
        
        self.items = [NSDictionary dictionaryWithContentsOfURL :[[NSBundle mainBundle] URLForResource:@"StreetLightMenu" withExtension:@"plist"]];
        
        [self.items writeToFile:filePath atomically:YES];
        [manager setAttributes:[NSDictionary dictionaryWithObject:[NSDate date] forKey:NSFileModificationDate] ofItemAtPath:[[NSBundle mainBundle] bundlePath] error:nil];
    }
    else {
        self.items = [NSDictionary  dictionaryWithContentsOfFile : filePath];
    }
    
   // fav = [self.items objectForKey:@"Favourites"];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *colorString = [defaults objectForKey:@"color"];
    
    UIColor *color;
    
    if ([colorString isEqualToString:@"Orange"]) {
        color = [UIColor orangeColor];
    }
    else if ([colorString isEqualToString:@"Red"]) {
        color = [UIColor redColor];
    }
    else if ([colorString isEqualToString:@"Cyan"]) {
        color = [UIColor cyanColor];
    }
    else if ([colorString isEqualToString:@"Yellow"]) {
        color = [UIColor yellowColor];
    }
    else if ([colorString isEqualToString:@"Green"]) {
        color = [UIColor greenColor];
    }
    
    else {
        color = [UIColor whiteColor];
    }
    
    [self.tv setBackgroundColor:color];
    fav = [_items objectForKey:@"Favourites"];
    [self.tv reloadData];
    
}

//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
//{
//    return ;
//}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [fav count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
        static NSString *CellIdentifier = @"Cellone";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            
        cell.textLabel.text = [fav objectAtIndex:indexPath.row];
            
            cell.backgroundColor =[UIColor cyanColor ];
            
            //NSLog(([cell.textLabel.text]),@"%@");
//        cell.imageView.image = [UIImage imageNamed:[Flags objectAtIndex:indexPath.row]];
//        
//        cell.detailTextLabel.text = [Capitals objectAtIndex:indexPath.row];
        
        }
    
   return cell;
    
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return  YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;

}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        [fav removeObjectAtIndex:indexPath.row];
        
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]
                         withRowAnimation:UITableViewRowAnimationFade];
        
        
        AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSString *filePath = delegate.plistPathInDocumentDirectory;
        
        self.items = [NSDictionary  dictionaryWithContentsOfFile : filePath];
            
            
            [self.items setValue:fav forKey:@"Favourites"];
        
            [self.items writeToFile:filePath atomically:YES];
        
    }
        //writing new array to plist
    
}





        //NSDictionary *favDict = [Favourites objectAtIndex:indexPath.row];
        
//        cell.textLabel.text = [favDict objectForKey:@"Favourites"];
//        cell.imageView.image = [UIImage imageNamed:[favDict objectForKey:@"flag"]];
//        cell.detailTextLabel.text = [favDict objectForKey:@"capital"];
//    
//       return cell;
    


@end
