//
//  DetailViewController.h
//  MyCookBook
//
//  Created by Neeraj Shukla on 31/10/14.
//  Copyright (c) 2014 stpl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lbl1;
@property (weak, nonatomic) IBOutlet UILabel *lbl2;
@property (weak, nonatomic) IBOutlet UILabel *lbl3;
@property (weak, nonatomic) IBOutlet UILabel *introlbl;
@property (weak, nonatomic) IBOutlet UILabel *timelbl;
@property (weak, nonatomic) IBOutlet UILabel *Ingredlbl;
@property (weak, nonatomic) IBOutlet UIButton *addBtn;
@property (nonatomic, strong) NSString *DishesName;
@property (weak, nonatomic) IBOutlet UIImageView *fullImage;
@property (nonatomic, assign) BOOL Check;
@property (nonatomic, assign) NSInteger favIndex;
@property(nonatomic,strong) NSDictionary *dishes;
- (IBAction)add:(id)sender;



@end
