//
//  SecondViewController.h
//  MyCookBook
//
//  Created by Neeraj Shukla on 31/10/14.
//  Copyright (c) 2014 stpl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(strong,nonatomic)NSDictionary *items;
@property (strong, nonatomic) IBOutlet UITableView *tv;
//@property(strong,nonatomic)UITableView *tableView;

//@property (weak, nonatom NSDictionary *itemsic) IBOutlet UIButton *add;
//@property (nonatomic, assign) BOOL Check;
//@property (nonatomic, assign) NSInteger favIndex;
//-(IBAction)addFavourites:(id)sender;

@end
