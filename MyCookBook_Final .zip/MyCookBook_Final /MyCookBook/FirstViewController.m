//
//  FirstViewController.m
//  MyCookBook
//
//  Created by Neeraj Shukla on 31/10/14.
//  Copyright (c) 2014 stpl. All rights reserved.
//

#import "FirstViewController.h"
#import "DetailViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController
{
    NSArray *Starters;
    NSArray *MainCourse;
    NSArray *Desserts;
    NSArray *Beverages;
    NSDictionary *Dishes;

}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSString *path = [[NSBundle mainBundle] pathForResource:@"StreetLightMenu" ofType:@"plist"];
    //Load the file content and read the data into arrays
    NSDictionary *dict = [[NSDictionary alloc] initWithContentsOfFile:path];
    
    Starters = [dict objectForKey:@"Starters"];
    MainCourse = [dict objectForKey:@"MainCourse"];
    Desserts = [dict objectForKey:@"Desserts"];
    Beverages=[dict objectForKey:@"Beverages"];
   
    /* Dishes = [dict objectForKey:@"Dishes"];
    NSArray *dishesArray = [Dishes allKeys];
    //int count = [dishesArray count];
    
    Starters = [dishesArray objectAtIndex:0];
    MainCourse = [dishesArray objectAtIndex:1];
    Dezzerts = [dishesArray objectAtIndex:2];
    Beverages=[dishesArray objectAtIndex:3];
    // Do any additional setup after loading the view, typically from a nib.

*/

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
        return 3;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if(section == 0)
    {
        return @"Starters";
    }
    else if(section == 1)
    {
        return @"Main Course";
    }
    else if(section == 2)
    {
        return @"Desserts";
    }
    else if(section == 3)
    {
        return @"Beverages";
    }
    else
    {
        return 0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"cell1";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    NSString *textString;
    if(indexPath.section==0)
    {
        textString=[[Starters objectAtIndex:indexPath.row]objectForKey:@"Name"];
    }
    else if(indexPath.section==1)
    {
        textString=[[MainCourse objectAtIndex:indexPath.row]objectForKey:@"Name"];
      }
    else if(indexPath.section==2)
    {
        textString=[[Desserts objectAtIndex:indexPath.row]objectForKey:@"Name"];
       }
    else if(indexPath.section==3)
    {
        textString=[[Beverages objectAtIndex:indexPath.row]objectForKey:@"Name"];
    }
    cell.backgroundColor=[UIColor cyanColor];
    cell.textLabel.text=textString;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DetailViewController *myVC = (DetailViewController *)[storyboard instantiateViewControllerWithIdentifier:@"detail"];
    
    if(indexPath.section==0)
    {
        myVC.dishes = [Starters objectAtIndex:indexPath.row];
    //[myVC setDishes:[Starters objectAtIndex:indexPath.row]];
    }
    
    if(indexPath.section==1)
    {
        myVC.dishes = [MainCourse objectAtIndex:indexPath.row];
    }
    
    if(indexPath.section==2)
    {
        myVC.dishes = [Desserts objectAtIndex:indexPath.row];
    }
    
    if(indexPath.section==3)
    {
        myVC.dishes = [Beverages objectAtIndex:indexPath.row];
    }
    
    [self.navigationController pushViewController:myVC animated:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *colorString = [defaults objectForKey:@"color"];
    
    UIColor *color;
    UIFont *Textfont;
    
    if ([colorString isEqualToString:@"Orange"]) {
        color = [UIColor orangeColor];
    }
    else if ([colorString isEqualToString:@"Red"]) {
        color = [UIColor redColor];
    }
    else if ([colorString isEqualToString:@"Cyan"]) {
        color = [UIColor cyanColor];
    }
    else if ([colorString isEqualToString:@"Yellow"]) {
        color = [UIColor yellowColor];
    }
    else if ([colorString isEqualToString:@"Green"]) {
        color = [UIColor greenColor];
    }
    
    else {
        color = [UIColor whiteColor];
    }
    
    [self.tableView setBackgroundColor:color];
    //[self.backgroundColor:color];
    [self.tableView reloadData];
    
    //Text FontChange
    
    NSString *fontString = [defaults objectForKey:@"Textfont"];
    
    if ([fontString isEqualToString:@"Helvetica Neue"]) {
        Textfont = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Marker Felt"]) {
        Textfont = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Georgia"]) {
        Textfont= [UIFont fontWithName:@"Georgia" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Times New Roman"]) {
        Textfont= [UIFont fontWithName:@"Times New Roman" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Verdana"]) {
        Textfont = [UIFont fontWithName:@"Verdana" size:12.0 ];
    }
    
    else {
        Textfont = [UIFont fontWithName:@"Avenir" size:12.0 ];
    }
    //[self.tableView.cell setfont:color];
    
    
}


/*
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showRecipeDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
       FirstViewController *destViewController = segue.destinationViewController;
        destViewController.de = [recipes objectAtIndex:indexPath.row];
        cell.textLabel.text = [[testdata objectAtIndex:indexPath.row]objectForKey:@"name"];

    }
}
*/
@end
