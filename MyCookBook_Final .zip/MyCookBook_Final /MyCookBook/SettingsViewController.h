//
//  SettingsViewController.h
//  MyCookBook
//
//  Created by Neeraj Shukla on 31/10/14.
//  Copyright (c) 2014 stpl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UISegmentedControl *changecolor;
@property (weak, nonatomic) IBOutlet UILabel *colorlbl;
@property (weak, nonatomic) IBOutlet UILabel *headinglbl;
@property (weak, nonatomic) IBOutlet UILabel *fontlbl;
@property (weak, nonatomic) IBOutlet UISegmentedControl *changeheading;
@property (weak, nonatomic) IBOutlet UISegmentedControl *changefont;
- (IBAction)changecolor:(id)sender;
- (IBAction)changeheading:(id)sender;
- (IBAction)changefont:(id)sender;

@end
