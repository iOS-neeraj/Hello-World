//
//  DetailViewController.m
//  MyCookBook
//
//  Created by Neeraj Shukla on 31/10/14.
//  Copyright (c) 2014 stpl. All rights reserved.
//

#import "DetailViewController.h"
#import "FirstViewController.h"
#import "AppDelegate.h"

//#import "FirstViewController.h"
@interface DetailViewController ()
//@property (strong, nonatomic) NSMutableArray *favourites;
@end

@implementation DetailViewController
 NSMutableArray *favourites;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//    if(_Check==TRUE )
//        _addbtn.hidden=YES;
    // Do any additional setup after loading the view.
    //_lbl1.text=;
   _lbl1.text =[_dishes objectForKey:@"Introduction"];
    _lbl2.text =[_dishes objectForKey:@"Ingredients"];
    _lbl3.text =[_dishes objectForKey:@"Time"];
    NSString *images=[_dishes objectForKey:@"Image"];
    _fullImage.image =[UIImage imageNamed:images];

    //UIImage *image = [UIImage imageNamed:self.fullImage];
    //[self.fullImage setImage:image];

   //UIImageView.images=images;
    
}
- (void)viewWillAppear:(BOOL)animated {
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *colorString = [defaults objectForKey:@"color"];
    
    UIColor *color;
    
    if ([colorString isEqualToString:@"Orange"]) {
        color = [UIColor orangeColor];
    }
    else if ([colorString isEqualToString:@"Red"]) {
        color = [UIColor redColor];
    }
    else if ([colorString isEqualToString:@"Cyan"]) {
        color = [UIColor cyanColor];
    }
    else if ([colorString isEqualToString:@"Yellow"]) {
        color = [UIColor yellowColor];
    }
    else if ([colorString isEqualToString:@"Green"]) {
        color = [UIColor greenColor];
    }
    
    else {
        color = [UIColor whiteColor];
    }
    
    [self.view setBackgroundColor:color];
    
    //Heading FontChange
    NSString *fontString = [defaults objectForKey:@"font"];
    
    UIFont *font,*Textfont;
    
    if ([fontString isEqualToString:@"Helvetica Neue"]) {
        font = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Marker Felt"]) {
        font = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Georgia"]) {
        font = [UIFont fontWithName:@"Georgia" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Times New Roman"]) {
        font = [UIFont fontWithName:@"Times New Roman" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Verdana"]) {
        font = [UIFont fontWithName:@"Verdana" size:12.0 ];
    }
    
    else {
        font = [UIFont fontWithName:@"Avenir" size:12.0 ];
    }
    
    [self.introlbl setFont:font];
    [self.Ingredlbl setFont:font];
    [self.timelbl setFont:font];
    
    
    // Text FontChange
    NSString *TextfontString = [defaults objectForKey:@"Textfont"];
    if ([TextfontString isEqualToString:@"Helvetica Neue"]) {
        Textfont = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
    }
    else if ([TextfontString isEqualToString:@"Marker Felt"]) {
        Textfont = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
    }
    else if ([TextfontString isEqualToString:@"Georgia"]) {
        Textfont= [UIFont fontWithName:@"Georgia" size:12.0 ];
    }
    else if ([TextfontString isEqualToString:@"Times New Roman"]) {
        Textfont= [UIFont fontWithName:@"Times New Roman" size:12.0 ];
    }
    else if ([TextfontString isEqualToString:@"Verdana"]) {
        Textfont = [UIFont fontWithName:@"Verdana" size:12.0 ];
    }
    
    else {
        Textfont = [UIFont fontWithName:@"Avenir" size:12.0 ];
    }
    [self.lbl1  setFont:Textfont];
    [self.lbl2  setFont:Textfont];
    [self.lbl3  setFont:Textfont];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(IBAction)add:(id)sender
{
    _DishesName =[_dishes objectForKey:@"Name"];
   // NSMutableDictionary *newDict = [NSMutableDictionary dictionary];
    
    //NSString *addDishes =_DishesName;
    //[newDict setObject:addDishes forKey:@"name"];
    //[newDict setObject:[NSString stringWithFormat:@"%ld", (long)_favIndex] forKey:@"favIndex"];
    //[self.Main addObject:newDict];
    
    /*
    NSString* plistPath = nil;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *filePath = [documentsDirectory stringByAppendingString:@"newList.plist"];
    */
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSString *filePath = delegate.plistPathInDocumentDirectory;
    
    NSFileManager* manager = [NSFileManager defaultManager];
    
    if ([manager fileExistsAtPath:filePath])
    {
    
        NSMutableDictionary *items = [[NSMutableDictionary alloc] initWithContentsOfFile:filePath];
        favourites = [NSMutableArray arrayWithArray:[items objectForKey:@"Favourites"]];
    
    [favourites addObject:_DishesName];
    
    [items setObject:favourites forKey:@"Favourites"];
            

    [items writeToFile:filePath atomically:YES];
    [manager setAttributes:[NSDictionary dictionaryWithObject:[NSDate date] forKey:NSFileModificationDate] ofItemAtPath:[[NSBundle mainBundle] bundlePath] error:nil];
            
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Favourite" message:@"Dishes added to favourites successfully!!!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alertView show];
    }
    
}

@end
