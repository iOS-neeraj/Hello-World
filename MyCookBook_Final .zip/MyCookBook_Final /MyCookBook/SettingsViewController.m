//
//  SettingsViewController.m
//  MyCookBook
//
//  Created by Neeraj Shukla on 31/10/14.
//  Copyright (c) 2014 stpl. All rights reserved.
//

#import "SettingsViewController.h"

@interface SettingsViewController ()

@end

@implementation SettingsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *colorString = [defaults objectForKey:@"color"];
    
    UIColor *color;
    
    if ([colorString isEqualToString:@"Orange"]) {
        color = [UIColor orangeColor];
    }
    else if ([colorString isEqualToString:@"Red"]) {
        color = [UIColor redColor];
    }
    else if ([colorString isEqualToString:@"Cyan"]) {
        color = [UIColor cyanColor];
    }
    else if ([colorString isEqualToString:@"Yellow"]) {
        color = [UIColor yellowColor];
    }
    else if ([colorString isEqualToString:@"Green"]) {
        color = [UIColor greenColor];
    }
    
    else {
        color = [UIColor whiteColor];
    }
    
    [self.view setBackgroundColor:color];
    
    //Heading FontChange
    NSString *fontString = [defaults objectForKey:@"font"];
    
    UIFont *font,*Textfont;
    
    if ([fontString isEqualToString:@"Helvetica Neue"]) {
        font = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Marker Felt"]) {
        font = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Georgia"]) {
        font = [UIFont fontWithName:@"Georgia" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Times New Roman"]) {
        font = [UIFont fontWithName:@"Times New Roman" size:12.0 ];
    }
    else if ([fontString isEqualToString:@"Verdana"]) {
        font = [UIFont fontWithName:@"Verdana" size:12.0 ];
    }
    
    else {
        font = [UIFont fontWithName:@"Avenir" size:12.0 ];
    }
    
    [self.headinglbl setFont:font];
    [self.colorlbl setFont:font];
    [self.fontlbl setFont:font];
    
    
    //Text FontChange
    
    NSString *TextfontString = [defaults objectForKey:@"Textfont"];
    if ([TextfontString isEqualToString:@"Helvetica Neue"]) {
        Textfont = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
    }
    else if ([TextfontString isEqualToString:@"Marker Felt"]) {
        Textfont = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
    }
    else if ([TextfontString isEqualToString:@"Georgia"]) {
        Textfont= [UIFont fontWithName:@"Georgia" size:12.0 ];
    }
    else if ([TextfontString isEqualToString:@"Times New Roman"]) {
        Textfont= [UIFont fontWithName:@"Times New Roman" size:12.0 ];
    }
    else if ([TextfontString isEqualToString:@"Verdana"]) {
        Textfont = [UIFont fontWithName:@"Verdana" size:12.0 ];
    }
    
    else {
        Textfont = [UIFont fontWithName:@"Avenir" size:12.0 ];
    }
    [self.headinglbl setFont:Textfont];
    [self.colorlbl setFont:Textfont];
    [self.fontlbl setFont:Textfont];

}

- (IBAction)changecolor:(id)sender {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    switch (_changecolor.selectedSegmentIndex) {
        case 0:
            [defaults setObject:@"Orange" forKey:@"color"];
            [self.view setBackgroundColor:[UIColor orangeColor]];
            
            break;
            
        case 1:
            [defaults setObject:@"Red" forKey:@"color"];
            [self.view setBackgroundColor:[UIColor redColor]];
            
            break;
            
        case 2:
            [defaults setObject:@"Cyan" forKey:@"color"];
            [self.view setBackgroundColor:[UIColor cyanColor]];
            break;
            
        case 3:
            [defaults setObject:@"Yellow" forKey:@"color"];
            [self.view setBackgroundColor:[UIColor yellowColor]];
            break;
            
        case 4:
            [defaults setObject:@"Green" forKey:@"color"];
            [self.view setBackgroundColor:[UIColor greenColor]];
            break;
            
        default:
            [defaults setObject:@"White" forKey:@"color"];
            [self.view setBackgroundColor:[UIColor whiteColor]];
            break;
    }
    
    [defaults synchronize];
}

- (IBAction)changeheading:(id)sender {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    UIFont *font;
    
    switch (_changeheading.selectedSegmentIndex) {
        case 0:
            [defaults setObject:@"Helvetica Neue" forKey:@"font"];
            self.headinglbl.font = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
            break;
            
        case 1:
            [defaults setObject:@"Marker Felt" forKey:@"font"];
            self.headinglbl.font = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
            break;
            
        case 2:
            [defaults setObject:@"Georgia" forKey:@"font"];
            self.headinglbl.font = [UIFont fontWithName:@"Georgia" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Georgia" size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Georgia" size:12.0 ];
            break;
            
        case 3:
            [defaults setObject:@"Times New Roman " forKey:@"font"];
            self.headinglbl.font = [UIFont fontWithName:@"Times New Roman" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Times New Roman," size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Times New Roman," size:12.0 ];
            break;
            
        case 4:
            [defaults setObject:@"Verdana" forKey:@"font"];
            self.headinglbl.font = [UIFont fontWithName:@"Verdana" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Verdana" size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Verdana" size:12.0 ];
            break;
            
        default:
            [defaults setObject:@"Avenir" forKey:@"font"];
            
            break;
    }
    
    [defaults synchronize];
}

- (IBAction)changefont:(id)sender {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    // UIFont *Textfont;
    
    
    switch (_changefont.selectedSegmentIndex) {
        case 0:
            [defaults setObject:@"Helvetica Neue" forKey:@"Textfont"];
            self.headinglbl.font = [UIFont fontWithName:@"Helvetica Neue" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Helvetica Neue " size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Helvetica Neue " size:12.0 ];
            
            break;
            
        case 1:
            [defaults setObject:@"Marker Felt" forKey:@"Textfont"];
            self.headinglbl.font = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Marker Felt" size:12.0 ];
            
            break;
            
        case 2:
            [defaults setObject:@"Georgia" forKey:@"Textfont"];
            self.headinglbl.font = [UIFont fontWithName:@"Georgia" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Georgia" size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Georgia" size:12.0 ];
            
            break;
            
        case 3:
            [defaults setObject:@"Times New Roman " forKey:@"Textfont"];
            self.headinglbl.font = [UIFont fontWithName:@"Times New Roman" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Times New Roman," size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Times New Roman," size:12.0 ];
            
            break;
            
        case 4:
            [defaults setObject:@"Verdana" forKey:@"Textfont"];
            self.headinglbl.font = [UIFont fontWithName:@"Verdana" size:12.0 ];
            self.colorlbl.font = [UIFont fontWithName:@"Verdana" size:12.0 ];
            self.fontlbl.font = [UIFont fontWithName:@"Verdana" size:12.0 ];
            break;
            
        default:
            [defaults setObject:@"Avenir" forKey:@"Textfont"];
            
            break;
            
    }
    
    [defaults synchronize];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
